BASE = "http://toptal.com"
BLOG = "/blog"
RESUME = "/resume"
SEARCH_BASE = "https://www.googleapis.com/customsearch/v1?key=AIzaSyCMGfdDaSfjqv5zYoS0mTJnOT3e9MURWkU&cx=003141353161291263905%3Avli4gva3h44&q="
#redis&start=1&num=10"

topics = {
    "backend" : "https://www.toptal.com/blog/back-end",
    "frontend" : "https://www.toptal.com/blog/web-front-end",
    "mobile" : "https://www.toptal.com/blog/mobile",
    "design" : "http://www.toptal.com/blog/design",
    "lifestyle" : "https://www.toptal.com/blog/lifestyle",
    "data science" : "https://www.toptal.com/blog/data-science-and-databases",
    "database" : "https://www.toptal.com/blog/data-science-and-databases",
    "technology" : "https://www.toptal.com/blog/technology",
    "project management" : "https://www.toptal.com/blog/project-management"
}
